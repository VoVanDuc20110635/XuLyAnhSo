import pywt
import numpy as np
import cv2
import os

def image_normalization(src_img):
    """
Normalization process to prevent overexposure
    cv2.Required when displaying wavelet-converted images with imshow (only for images with large values)
    """
    norm_img = (src_img - np.min(src_img)) / (np.max(src_img) - np.min(src_img))
    return norm_img

def merge_images(cA, cH_V_D):
    """numpy.4 array(upper left,(Upper right, lower left, lower right))Connect"""
    cH, cV, cD = cH_V_D
    cH = image_normalization(cH) #Even if you remove it, it's ok
    cV = image_normalization(cV) #Even if you remove it, it's ok
    cD = image_normalization(cD) #Even if you remove it, it's ok
    cA = cA[0:cH.shape[0], 0:cV.shape[1]] #If the original image is not a power of 2, there may be fractions, so adjust the size. Match the smaller one.
    return np.vstack((np.hstack((cA,cH)), np.hstack((cV, cD)))) #Attach pixels at top left, top right, bottom left, bottom right

def coeffs_visualization(cof):
    norm_cof0 = cof[0]
    norm_cof0 = image_normalization(norm_cof0) #Even if you remove it, it's ok
    merge = norm_cof0
    for i in range(1, len(cof)):
        merge = merge_images(merge, cof[i])  #Match the four images
    cv2.imshow('', merge)
    cv2.waitKey(0)
    cv2.destroyAllWindows()

def wavelet_transform_for_image(src_image, level, M_WAVELET="db1", mode="sym"):
    data = src_image.astype(np.float64)
    coeffs = pywt.wavedec2(data, M_WAVELET, level=level, mode=mode)
    return coeffs

if __name__ == "__main__":

    path_file=os.path.split(os.path.abspath(__file__))[0]
    file_image='ca-chua-1.jpg'
    file = os.path.join(path_file, file_image)
    LEVEL = 3

    MOTHER_WAVELET = "db1"

    im = cv2.imread(file)
    cv2.imshow('in', im)
    cv2.waitKey(0)

    print('LEVEL :', LEVEL)
    print('MOTHER_WAVELET', MOTHER_WAVELET)
    print('original image size: ', im.shape)

    """
Convert for each BGR channel
    cv2.imread is B,G,Note that the images are spit out in the order of R.
    """
    B = 0
    G = 1
    R = 2
    coeffs_B = wavelet_transform_for_image(im[:, :, B], LEVEL, M_WAVELET=MOTHER_WAVELET)
    coeffs_G = wavelet_transform_for_image(im[:, :, G], LEVEL, M_WAVELET=MOTHER_WAVELET)
    coeffs_R = wavelet_transform_for_image(im[:, :, R], LEVEL, M_WAVELET=MOTHER_WAVELET)

    coeffs_visualization(coeffs_B)
    coeffs_visualization(coeffs_G)
    coeffs_visualization(coeffs_R)